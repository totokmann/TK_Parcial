<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start(); 

$host = "localhost";
$db_username = "root";
$db_password = ""; 
$dbname = "tk_parcial"; 
$port = 3306;
global $conn;
$conn = new mysqli($host, $db_username, $db_password, $dbname, $port);

if ($conn->connect_error) {
   die("Conexión fallida: " . $conn->connect_error);
}

?>
