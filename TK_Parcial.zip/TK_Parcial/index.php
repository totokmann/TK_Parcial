<?php
include 'connection.php'; 
if (!isset($_SESSION['name'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio - TK Inmobiliaria</title>
    <link rel="stylesheet" href="CSS/style.css">
</head>
<body>
    <header>
        <h1>TK Inmobiliaria</h1>
        <nav>
            <ul>
            <li><a href="index.php?modulo=inicio">Inicio</a></li>
            <li><a href="index.php?modulo=propiedades">Propiedades</a></li>
            <li><a href="index.php?modulo=contacto">Contacto</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <?php
            if(!empty($_GET['modulo']))
            {
                include('modules/'.
            $_GET['modulo'].'.php');
            } 
        ?>
    </main>

    <footer>
        <p>&copy; 2024 TK Inmobiliaria. Todos los derechos reservados.</p>
        <p>Contacto: info@tkinmobiliaria.com | Tel: +54 9 1234-5678</p>
    </footer>
    <script src="JS/main.js"></script>
</body>
</html>
