<?php 
include 'connection.php'; 

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $mail = $_POST['mail'];
    $password = $_POST['password'];
    $register = "INSERT INTO user (name,mail,password) VALUES (?, ?, ?)";
    $stmt_register = $conn->prepare($register);
    $stmt_register->bind_param("sss", $name, $mail, $password);
    $stmt_register->execute();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro</title>
    <link rel="stylesheet" href="CSS/style.css">
</head>
<body>
    <header>
        <h1>Registro</h1>
    </header>

    <main>
        <form action="register.php" method="POST" class="form-container">
            <label for="name">Usuario</label>
            <input type="text" id="name" name="name" required>

            <label for="mail">Correo Electrónico</label>
            <input type="email" id="mail" name="mail" required>

            <label for="password">Contraseña</label>
            <input type="password" id="password" name="password" required>

            <button type="submit">Registrarse</button>

            <p>¿Ya tienes una cuenta? <a href="login.php">Inicia sesión aquí</a></p>
        </form>
    </main>
    <footer>
        <p>&copy; <?php echo date("Y"); ?> Mi Página. Todos los derechos reservados.</p>
    </footer>
</body>
</html>
