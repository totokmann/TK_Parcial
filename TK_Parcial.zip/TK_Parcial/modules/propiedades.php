<div class="listado-propiedades">
    <div class="propiedad-item">
        <a href="propiedades/casa1.html" target="_blank">
            <img src="imagenes/casa1.jpg" alt="Imagen de la propiedad" class="miniatura">
            <h4>Casa en Buenos Aires</h4>
        </a>
    </div>
    <div class="propiedad-item">
        <a href="propiedades/depto1.html" target="_blank">
            <img src="imagenes/depto1.jpg" alt="Imagen de la propiedad" class="miniatura">
            <h4>Departamento en Córdoba</h4>
        </a>
    </div>
    <div class="propiedad-item">
        <a href="propiedades/casa2.html" target="_blank">
            <img src="imagenes/casa2.jpg" alt="Imagen de la propiedad" class="miniatura">
            <h4>Casa en Rosario</h4>
        </a>
    </div>
</div>
