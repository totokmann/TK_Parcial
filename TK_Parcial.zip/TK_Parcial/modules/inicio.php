<section class="rotador-propiedades">
    <h2>Propiedades Destacadas</h2>
    <div class="carousel" id="carousel"></div>
</section>