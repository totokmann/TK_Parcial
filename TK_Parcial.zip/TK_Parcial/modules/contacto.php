<div class="contacto">
    <h2>Contáctanos</h2>
    <p>Para consultas sobre nuestras propiedades o servicios, completa el formulario a continuación o comunícate con nosotros a través de los medios disponibles.</p>
    
    <div class="info-contacto">
        <p><strong>Dirección:</strong> Av. Principal 123, Buenos Aires, Argentina</p>
        <p><strong>Teléfono:</strong> +54 9 1234-5678</p>
        <p><strong>Email:</strong> info@tkinmobiliaria.com</p>
    </div>

    <form action="procesar_contacto.php" method="POST" class="formulario-contacto">
        <label for="nombre">Nombre:</label>
        <input type="text" id="nombre" name="nombre" required>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required>

        <label for="telefono">Teléfono:</label>
        <input type="tel" id="telefono" name="telefono">

        <label for="mensaje">Mensaje:</label>
        <textarea id="mensaje" name="mensaje" rows="4" required></textarea>

        <button type="submit">Enviar Mensaje</button>
    </form>
</div>
