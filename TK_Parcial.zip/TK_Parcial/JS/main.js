// Datos de las propiedades
const propiedades = [
    { tipo: "Casa en Buenos Aires", url_imagen: "imagenes/casa1.jpg" },
    { tipo: "Departamento en Córdoba", url_imagen: "imagenes/depto1.jpg" },
    { tipo: "Casa en Posadas", url_imagen: "imagenes/casa2.jpg" }
];

// Insertar el HTML para cada propiedad destacada
const carousel = document.getElementById('carousel');

propiedades.forEach(propiedad => {
    const item = document.createElement('div');
    item.classList.add('carousel-item');
    item.innerHTML = `
        <img src="${propiedad.url_imagen}" alt="Imagen de la propiedad">
        <h3>${propiedad.tipo}</h3>
    `;
    carousel.appendChild(item);
});

// Funcionalidad del rotador
let index = 0;
const items = document.querySelectorAll('.carousel-item');
const totalItems = items.length;

function showItem(i) {
    items.forEach(item => item.style.display = 'none'); // Ocultar todas
    items[i].style.display = 'block'; // Mostrar la actual
}

function nextItem() {
    index = (index + 1) % totalItems;
    showItem(index);
}

document.addEventListener("DOMContentLoaded", function() {
    showItem(index);
    setInterval(nextItem, 3000); // Cambiar cada 3 segundos
});
