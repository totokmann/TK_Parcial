create database tk_parcial;
use tk_parcial;

create table user(
    user_id int auto_increment primary key,
    name varchar(255) not null,    
    mail varchar(100) not null,
    password varchar(50) not null
);

select * from user;
